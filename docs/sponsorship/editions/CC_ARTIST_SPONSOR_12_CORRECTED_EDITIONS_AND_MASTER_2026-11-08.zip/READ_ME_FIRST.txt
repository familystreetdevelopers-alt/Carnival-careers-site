CARNIVAL CAREERS - CORRECTED ARTIST SPONSORSHIP FULL EDITION SET
Dated 8 November 2026, correcting an editorial error in prior sponsor materials.

CURRENT EVENT PARTNER DEAL PAYMENT STRUCTURE:
1. The first increment is payable when Hopeton is actually admitted through the authorized venue door.
2. The second increment is payable once named ORIGINAL CARNIVAL CAREERS MUSIC is confirmed in the actual event AUDIO / SET LINEUP (not merely Hopeton being in the artist lineup).
3. The third increment is payable once Hopeton sings and completes his LAST SONG on stage.

Amounts per increment, total partner fee, evidence, payee, cancellations, escrow and live rights
require a new signed event-specific agreement. A former C$9K illustration does not revoke
or supersede this payment schedule. Sponsors receive separate marketing deliverables.

CONTENTS: 12 sponsor edition PDFs (six tiers x with/without a separately disclosed
real-estate narrative), one corrected 15-page master benefits prospectus, one event-partner
term sheet, and the SHA-256 manifest. The 12 new editions are companion sponsor proposals.
They do NOT claim to embed or alter the two original Adobe Creative Cloud historical PDF masters.
Original historical PDF pages and signed documents must remain unchanged.

No venue, show, artist, sponsor or property financing agreement is represented as accepted.
No contacts or messages were sent. GitHub remains the master storage destination.
